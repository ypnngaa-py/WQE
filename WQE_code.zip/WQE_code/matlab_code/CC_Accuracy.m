%% NBS demo of recovering and simulating data
%

library_path = '/Users/yangpan/Downloads/nbs_release_v0.2/';
basedata_path = '/Users/yangpan/Downloads/';

addpath(genpath(library_path))

%% Load somatic mutation cancer data
% 
% sim_indiv_clabel = load([ library_path '/Data_Simulation/sim_indiv_clabel_k4_0.1_200.txt' ]);
% bkg_gene_ids = load([ library_path '/Data_Simulation/bkg_gene_ids_k4_0.1_200.txt']);
% sim_matrix = load([ library_path '/Data_Simulation/sim_matrix_k4_0.1_200.txt']);

%%
% cc = load([basedata_path '/rerealdatasetpilot/consensus_kirc_mutation_smoothed_matrix.txt4.txt']);
% [mut] = calc_label(cc,4,'av',1);
%cc = load([basedata_path '/Exp/consensus_nocol_OV_normalized_results_processed.txt4.txt']);
% [exp] = calc_label(cc,4,'av',1);
cc = load([basedata_path 'Consensus_Mat/real_data_consensus/consensus_filtered_OV_exp.csv_5_0.txt']);
[ctrl_cc_label1] = calc_label(cc,5,'av',1);
cc = load([basedata_path 'Consensus_Mat/real_data_consensus/consensus_filtered_OV_mut_smoothed.csv_5_1000.txt']);
[ctrl_cc_label2] = calc_label(cc,5,'av',1);
cc = load([basedata_path 'Consensus_Mat/real_data_consensus/consensus3.txt']);
[ctrl_cc_label3] = calc_label(cc,5,'av',1);

%sim_indiv_clabel1= load([basedata_path 'Exp/1.txt']);
%sim_indiv_clabel2= load([basedata_path 'Exp/2.txt']);
%sim_indiv_clabel= load([basedata_path 'kirc/pathologic_tumor_stage.txt']);
%sim_indiv_clabel= load([library_path 'Data_Simulation/sim_indiv_clabel_k4_0.075_200.txt']);
%[ctrl_cc_label] = calc_label(cc,4,'av',1);
[AR,RI,MI,HI]=RandIndex(ctrl_cc_label1,ctrl_cc_label2);
fprintf('Sim_matrix: RI:%f AR:%f\n',RI,AR);
[AR,RI,MI,HI]=RandIndex(ctrl_cc_label1,ctrl_cc_label3);
fprintf('Sim_matrix: RI:%f AR:%f\n',RI,AR);
[AR,RI,MI,HI]=RandIndex(ctrl_cc_label2,ctrl_cc_label3);
fprintf('Sim_matrix: RI:%f AR:%f\n',RI,AR);