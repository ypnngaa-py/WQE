"""
    To run the example simply type::
        
        python all_aml.py
        
    or call the module's function::
    
        import nimfa.examples
        nimfa.examples.all_aml.run()
        
    .. note:: This example uses ``matplotlib`` library for producing a heatmap of a consensus matrix.
"""
from os.path import dirname, abspath, join
from warnings import warn
import cPickle as pickle
from scipy.cluster.hierarchy import linkage, leaves_list, cophenet
from scipy.spatial.distance import squareform
import numpy as np
import nimfa,sys
RUN=10
try:
    from matplotlib.pyplot import savefig, imshow, set_cmap
except ImportError as exc:
    warn("Matplotlib must be installed to run ALL AML example.")


def run(fin1,fin2):
    """Run Standard NMF on leukemia data set. """
    V = read(fin1)
    V1 = V
    glap = read_mat(fin2)
    #glap=None
    # with open('knnGlap.dat', 'wb') as outfile:
    #     pickle.dump(glap, outfile, pickle.HIGHEST_PROTOCOL)
    for rank in range(3, 4):
        #run_one(V, rank, glap)
        run_one(V, rank, glap, V1)

def run_one(V, rank, glap, V1):
    """
    Run standard NMF on leukemia data set. 50 runs of Standard NMF are performed and obtained consensus matrix
    averages all 50 connectivity matrices.
    :param V: Target matrix with gene expression data.
    :type V: `numpy.ndarray`
    :param rank: Factorization rank.
    :type rank: `int`
    """
    print("================= Rank = %d =================" % rank)
    consensus = np.zeros((V.shape[0], V.shape[0]))
    for i in range(RUN):
        #nmf = nimfa.Nmf(V, rank=rank, max_iter=500)
        #nmf = nimfa.Nsnmf(V, rank=rank, max_iter=200, theta=0)
    	#nmf = nimfa.Gnsnmf(V, rank=rank, max_iter=200, theta=0, L=glap, lamb= 0.000001)
        #nmf = nimfa.Gnmf(V, rank=rank, max_iter=200, L=glap, fgamma= 0.001)
        nmf = nimfa.Snmnmf(V, V1, rank=rank, max_iter=200, A=glap)
        fit = nmf()
        print("%2d/%2d : %s - init: %s (%3d/200 iterations)" % (i + 1,RUN, fit.fit,
                                                               fit.fit.seed, fit.fit.n_iter))
        
        print fit.fit.sparseness(1)
        print fit.fit.evar(1)
        print fit.fit.basis().shape,fit.fit.coef(1).shape
        consensus += fit.fit.connectivity(idx=0)
        print consensus
    consensus /= float(RUN)
    print 'cophenet:',cop_value(consensus)

    np.savetxt('consensus%d.txt'% rank,consensus)

    #p_consensus = reorder(consensus)
    #plot(p_consensus, rank)

def cop_value(consensus):
    # upper diagonal elements of consensus
    avec = np.array([consensus[i, j] for i in range(consensus.shape[0] - 1)
                    for j in range(i + 1, consensus.shape[1])])
    # consensus entries are similarities, conversion to distances
    Y = 1 - avec
    Z = linkage(Y, method='average')
    # cophenetic correlation coefficient of a hierarchical clustering
    # defined by the linkage matrix Z and matrix Y from which Z was
    # generated
    return cophenet(Z, Y)[0]

def plot(C, rank):
    """
    Plot reordered consensus matrix.
    :param C: Reordered consensus matrix.
    :type C: numpy.ndarray`
    :param rank: Factorization rank.
    :type rank: `int`
    """
    imshow(C)
    #set_cmap("RdBu_r")
    savefig("all_aml_consensus_%d.png" % rank)


def reorder(C):
    """
    Reorder consensus matrix.
    :param C: Consensus matrix.
    :type C: `numpy.ndarray`
    """
    Y = 1 - C
    Z = linkage(squareform(Y), method='average')
    ivl = leaves_list(Z)
    ivl = ivl[::-1]
    return C[:, ivl][ivl, :]


def read(fin):
    """
    Read ALL AML gene expression data. The matrix's shape is 5000 (genes) x 38 (samples).
    It contains only positive data.
    Return the gene expression data matrix.
    """
    # __file__='/Library/Python/2.7/site-packages/nimfa/examples/all_aml.py'
    # fname = join(dirname(dirname(abspath(__file__))), 'datasets', 'ALL_AML', 'ALL_AML_data.txt')
    # V = np.loadtxt(fname)
    import scipy.sparse as spr
    f=open(fin,'r')
    #l=[ map(int,line.split(',')) for line in f ]
    V = np.loadtxt(f,delimiter=',')
    #V = np.transpose(V)
    print V.shape
    return V

def read_mat(fin):
    """
    Read ALL AML gene expression data. The matrix's shape is 5000 (genes) x 38 (samples).
    It contains only positive data.
    Return the gene expression data matrix.
    """
    import scipy as sp
    with open(fin) as infile:
        G = pickle.load(infile)
    G = sp.sparse.csr_matrix(G)
    print G.shape
    return G

if __name__ == "__main__":
    """Run the ALL AML example."""
    run(sys.argv[1],sys.argv[2])