library(NMF)
#data(esGolub)
mat<- read.csv('nbs_release_v0.2/CC_NMF_0.15.txt',header = F)
mat<- read.table('consensus3.txt',header = F)
mat[is.na(mat)] <- 0
mat<- as.matrix(mat)
#a<-res@consensus

#Compare heatmaps
#heatmap(a)
#heatmap(a, Rowv = NA, Colv = NA)
#consensusmap(a)
consensusmap(mat)
heatmap(mat)
heatmap(mat, Rowv= NA, Colv = NA)


